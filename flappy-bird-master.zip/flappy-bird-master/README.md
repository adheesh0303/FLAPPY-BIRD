# flappy-bird

This is a flappy bird clone made with pure JS and canvas.
